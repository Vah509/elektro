---
id: 260706182121
title: "Шафа керування зенітними ліхтарями на ПЛК ОВЕН ПР100"
seoTitle: "Шафа зенітних ліхтарів на ОВЕН ПР100 | elektroschit.com.ua"
date: 2022-08-01
types: ["zenitni-lihtari", "plk"]
tags: []
properties: ["pryamyi-pusk"]
description: "Шафа керування зенітними ліхтарями на ПЛК ОВЕН ПР100. Дві зони, три приводи, 11 реле ETI, блок живлення Mean Well 24В/40А."
specs:
  - label: "ПЛК"
    value: "ОВЕН ПР100 (8 DI, 4 AI, 8 DO)"
  - label: "Кількість зон"
    value: "2 зони"
  - label: "Кількість приводів"
    value: "3 приводи (Ф1.1, Ф1.2, Ф1.3)"
  - label: "Виконавчі реле"
    value: "ETI EDB-207, 11 каналів (K1–K11)"
  - label: "Блок живлення"
    value: "Mean Well SDR-960-24, 24В / 40А"
  - label: "Керування"
    value: "Ручне з лицевої панелі — кнопки пуск/стоп по кожній зоні та приводу"
  - label: "Сигналізація"
    value: "Індикація стану приводів, загальна аварія"
  - label: "Тип пуску"
    value: "Прямий пуск"
  - label: "Інтерфейс зв'язку"
    value: "RS-485"
  - label: "Гарантія"
    value: "12 місяців"
brands: ["ОВЕН", "ETI", "Mean Well"]
photos:
  - src: "/images/vykonani-roboty/shafa-keruvannia-zenitni-lihtari-ovr-pr100/shafa-keruvannia-zenitni-lihtari-ovr-pr100-zahalnyi-vyd-vidkrytyi-kyiv-2022-08-01.jpg"
    caption: "Загальний вигляд відкритої шафи — ПЛК, реле, блок живлення"
  - src: "/images/vykonani-roboty/shafa-keruvannia-zenitni-lihtari-ovr-pr100/shafa-keruvannia-zenitni-lihtari-ovr-pr100-plk-ovr-pr100-rele-kyiv-2022-08-02.jpg"
    caption: "ПЛК ОВЕН ПР100 та реле ETI EDB-207 — крупний план"
  - src: "/images/vykonani-roboty/shafa-keruvannia-zenitni-lihtari-ovr-pr100/shafa-keruvannia-zenitni-lihtari-ovr-pr100-litseva-panel-knoky-kyiv-2022-08-03.jpg"
    caption: "Лицева панель — кнопки керування по зонах та приводах, індикатори стану"
---

Шафа керування зенітними ліхтарями виконана на базі програмованого логічного контролера ОВЕН ПР100. Шафа забезпечує керування приводами двох незалежних зон з можливістю ручного управління безпосередньо з лицевої панелі.

Виконавча частина побудована на 11 реле ETI EDB-207, згрупованих по каналах K1–K11. Живлення керуючих кіл — від блоку Mean Well SDR-960-24 (24В / 40А). Зв'язок з верхнім рівнем автоматизації передбачений через інтерфейс RS-485.

Лицева панель оснащена кнопками пуск/стоп для кожної зони та кожного приводу окремо, а також кнопкою загального аварійного відключення. Індикаторні лампи відображають поточний стан відкриття приводів та сигналізують про аварійні ситуації.
